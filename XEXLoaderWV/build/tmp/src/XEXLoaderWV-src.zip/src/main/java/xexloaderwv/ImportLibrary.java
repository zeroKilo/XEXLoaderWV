package xexloaderwv;
import java.util.ArrayList;

public class ImportLibrary {
	public String name;
	public ArrayList<Integer> records = new ArrayList<Integer>();
	public ArrayList<ImportFunction> functions = new ArrayList<ImportFunction>();
}
