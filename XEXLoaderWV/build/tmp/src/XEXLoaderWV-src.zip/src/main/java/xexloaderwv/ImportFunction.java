package xexloaderwv;

public class ImportFunction {
	public int address;
	public int ordinal;
	public int thunk;
}
